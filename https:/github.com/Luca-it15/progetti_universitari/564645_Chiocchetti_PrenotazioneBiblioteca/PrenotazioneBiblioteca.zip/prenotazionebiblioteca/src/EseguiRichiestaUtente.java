
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.*; 

public class EseguiRichiestaUtente {
    private PrenotazioneBibliotecaGUI interfacciaGrafica; 
    private DialogaConDB dcb; 
    public EseguiRichiestaUtente(PrenotazioneBibliotecaGUI interfacciaGrafica) {
        dcb = new DialogaConDB(); //1) 
        this.interfacciaGrafica = interfacciaGrafica;  
    }
    
    public void inizializzaTabella() { //2)
       if(interfacciaGrafica.listaTavolo != null)
        interfacciaGrafica.tabellaTavoli.getItems().removeAll(interfacciaGrafica.listaTavolo); 
      
       
      String nome = interfacciaGrafica.campoNomeUtente.getText(); 
      LocalDate data = interfacciaGrafica.calendario.getValue(); 
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        
      interfacciaGrafica.listaTavolo = dcb.inizializzaTabellaTavoliDB(nome, data.format(formatter),
                                                                     (String)interfacciaGrafica.turnoLista.getValue()); 
      interfacciaGrafica.tabellaTavoli.setItems(interfacciaGrafica.listaTavolo);
    }
    
    public void aggiungiPrenotazione() { //3) 
      String nome = interfacciaGrafica.campoNomeUtente.getText(); 
      LocalDate data = interfacciaGrafica.calendario.getValue(); 
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
      String dataString = data.format(formatter); 
      String turno = (String)interfacciaGrafica.turnoLista.getValue(); 
      StatoTavoloGiorno stg = interfacciaGrafica.tabellaTavoli.getSelectionModel().getSelectedItem(); 
      int tavolo = stg.getTavolo(); 
      String tipo = stg.getTipo(); 
      String libro = stg.getLibro().getText(); 
      if(dcb.aggiungiPrenotazioneDB(nome, dataString , turno, tavolo, tipo, libro)) { 
          inizializzaTabella(); 
      } else 
           stg.getLibro().setStyle("-fx-text-fill: red"); 
    }
    
    public void cancellaPrenotazione() { //4) 
      String nome = interfacciaGrafica.campoNomeUtente.getText(); 
      LocalDate data = interfacciaGrafica.calendario.getValue(); 
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
      String dataString = data.format(formatter); 
      String turno = (String)interfacciaGrafica.turnoLista.getValue(); 
      if(dcb.cancellaPrenotazioneDB(nome, dataString , turno)) { 
          inizializzaTabella(); 
      } else 
           System.err.println("Errore durante la cancellazione della prenotazione"); 
    }
    
    public void inizializzaDatiGrafico() { //5) 
     LocalDate dataConfronto = interfacciaGrafica.dataDa.getValue(); 
      DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");   
      DateTimeFormatter formatterDB = DateTimeFormatter.ofPattern("yyyy-MM-dd"); //formattatore per le query nel db 
      String data = dataConfronto.format(formatter1); 
      System.out.println(data); 
      String[] componentiData = data.split("/"); 
      String[] dataDiOggi = interfacciaGrafica.dataA.getText().split("/"); 
      int giornoDaCuiIniziare = Integer.parseInt(componentiData[0]); 
      System.out.println(giornoDaCuiIniziare);
      int meseDaCuiIniziare = Integer.parseInt(componentiData[1]); 
      int annoDaCuiIniziare = Integer.parseInt(componentiData[2]); 
      int giornoDiOggi = Integer.parseInt(dataDiOggi[0]); 
      int meseDiOggi = Integer.parseInt(dataDiOggi[1]); 
      int annoDiOggi = Integer.parseInt(dataDiOggi[2]); 
      int numDiGiorni = ((giornoDiOggi + meseDiOggi*30 + (annoDiOggi - 1) * 12 *30) - 
                          (giornoDaCuiIniziare + meseDaCuiIniziare * 30 + (annoDaCuiIniziare - 1) * 12 * 30)); 
      CategoryAxis xAxis = new CategoryAxis(); 
      xAxis.setLabel("Giorni"); 
      NumberAxis yAxis = new NumberAxis(0, 16, 1); 
      yAxis.setLabel("Numero Prenotazioni");
      interfacciaGrafica.lineaGraficoCorrente = new XYChart.Series(); 
      interfacciaGrafica.lineaGraficoCorrente.setName("Anno Corrente");
      interfacciaGrafica.lineaGraficoPassato = new XYChart.Series(); 
      interfacciaGrafica.lineaGraficoPassato.setName("Anno Passato");
      interfacciaGrafica.grafico = new LineChart<String, Number>(xAxis, yAxis);
      LocalDate dataTarget = dataConfronto; 
      for(int i = 0; i < numDiGiorni; i++) {
        interfacciaGrafica.lineaGraficoCorrente.getData().add(new XYChart.Data(dataTarget.format(formatter1), dcb.numeroPrenotazioni(dataTarget.format(formatterDB))));    
        dataTarget = dataTarget.plusDays(1); 
      }
      dataTarget = dataConfronto; 
      int anniDiDifferenza = annoDaCuiIniziare - Integer.parseInt((String)interfacciaGrafica.annoConfronto.getValue()); 
      dataTarget = dataTarget.minusYears(anniDiDifferenza); 
      for(int i = 0; i < numDiGiorni; i++) {
        interfacciaGrafica.lineaGraficoPassato.getData().add(new XYChart.Data(dataTarget.format(formatter1), dcb.numeroPrenotazioni(dataTarget.format(formatterDB))));    
        dataTarget = dataTarget.plusDays(1); 
      }
     interfacciaGrafica.grafico.getData().add(interfacciaGrafica.lineaGraficoCorrente); 
     interfacciaGrafica.grafico.getData().add(interfacciaGrafica.lineaGraficoPassato);  
    } 
}

/*
 ----------COMMENTI------------------
1) tra i campi della classe abbiamo un riferimento di tipo DialogaConDB in modo da poter 
   utilizzare i metodi della classe e dialogare con il database 
2) il metodo si occupa di inizializzare la tabella dei tavoli con valori presenti 
   sull'interfaccia grafica nel momento in cui viene chiamato il metodo. 
   utilizza il metodo InizializzaTabellaTavoli della classe DialogaConDB per recuperare
   le informazioni dal database 
3) il metodo si occupa di aggiungere una prenotazione al database utlizzando il metodo 
   aggiugiPrenotazioneDB della classe DialogaConDB e aggiorna la tabella dei tavoli
4) il metodo si occupa di cancellare una prenotazione nel database utlizzando il metodo 
   cancellaPrenotazioneDB della classe DialogaConDB e aggiorna la tabelle dei tavoli
5) il metodo si occupa di inizializzare i dati del grafico utilizzando il metodo 
   numeroPrenotazioni della classe DialogaConDB 
*/