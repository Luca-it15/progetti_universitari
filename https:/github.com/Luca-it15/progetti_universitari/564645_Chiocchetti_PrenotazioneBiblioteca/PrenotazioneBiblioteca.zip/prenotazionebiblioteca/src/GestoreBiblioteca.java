
import java.time.*;
import java.time.format.*;
import java.util.*;
import javafx.collections.*;
import javafx.event.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.*; 


public class GestoreBiblioteca {  //1)
    private PrenotazioneBibliotecaGUI ig; 
    private EseguiRichiestaUtente richiestaUtente; 
    public ParametriDiConfigurazione parametriConfigurazione; 
    private InvioEventoAServerDiLog inviaEventoUtente;
    private CachePrenotazioneBiblioteca cacheDati;
    
    public GestoreBiblioteca(PrenotazioneBibliotecaGUI ig) { 
        this.ig = ig; 
        parametriConfigurazione = new ParametriDiConfigurazione(); //2)
        richiestaUtente = new EseguiRichiestaUtente(ig); 
        cacheDati = new CachePrenotazioneBiblioteca(ig);  //2)
        inviaEventoUtente = new InvioEventoAServerDiLog();  //2)
    }
    
   
  public void inizializzaDatiBiblioteca() { //3)
      cacheDati.caricaDatiDaCache();
      richiestaUtente.inizializzaTabella();
      cacheDati.caricaDatiCacheInTabella();
      DateTimeFormatter formatter = DateTimeFormatter.
                ofPattern("yyyy-MM-dd HH:mm:ss z",Locale.ITALY).withZone(ZoneId.of("Europe/Rome"));
      LocalDateTime oggi = LocalDateTime.now(); 
      formatter = formatter.withLocale(Locale.ITALY);
      String timestamp = oggi.format(formatter); 
      EventoUtente e = new EventoUtente("PrenotazioneBiblioteca","localhost",timestamp, "AVVIO"); 
     inviaEventoUtente.inviaEvento(e);
  }  
    
  public void prenotaPostoBiblioteca() {  //4)
      ig.prenota.setOnAction((ActionEvent ev) -> { richiestaUtente.aggiungiPrenotazione();  
         DateTimeFormatter formatter = DateTimeFormatter.
                ofPattern("yyyy-MM-dd HH:mm:ss z",Locale.ITALY).withZone(ZoneId.of("Europe/Rome"));
          LocalDateTime oggi = LocalDateTime.now(); 
          formatter = formatter.withLocale(Locale.ITALY);
          String timestamp = oggi.format(formatter); 
          EventoUtente e = new EventoUtente("PrenotazioneBiblioteca","localhost",timestamp, "Prenota"); 
        inviaEventoUtente.inviaEvento(e);
     });
  }
    
  public void  disdiciPostoBiblioteca() { //5)
      ig.cancella.setOnAction((ActionEvent ev) -> { richiestaUtente.cancellaPrenotazione(); 
     DateTimeFormatter formatter = DateTimeFormatter.
                ofPattern("yyyy-MM-dd HH:mm:ss z",Locale.ITALY).withZone(ZoneId.of("Europe/Rome"));
          LocalDateTime oggi = LocalDateTime.now(); 
              formatter = formatter.withLocale(Locale.ITALIAN);
          String timestamp = oggi.format(formatter); 
          EventoUtente e = new EventoUtente("PrenotazioneBiblioteca","localhost",timestamp, "Cancella"); 
        inviaEventoUtente.inviaEvento(e);
     });
  }
  
  public void confrontaDateGrafico(VBox vgrafico) { //6)
      ig.confronta.setOnAction((ActionEvent ev) ->  { 
          vgrafico.getChildren().remove(1); 
          richiestaUtente.inizializzaDatiGrafico();
          vgrafico.getChildren().add(ig.grafico); 
          DateTimeFormatter formatter = DateTimeFormatter.
                    ofPattern("yyyy-MM-dd HH:mm:ss z",Locale.ITALY).withZone(ZoneId.of("Europe/Rome"));
          LocalDateTime oggi = LocalDateTime.now(); 
          formatter = formatter.withLocale(Locale.FRENCH); 
          String timestamp = oggi.format(formatter); 
          EventoUtente e = new EventoUtente("PrenotazioneBiblioteca","localhost",timestamp, "Confronta"); 
       inviaEventoUtente.inviaEvento(e);
       ig.grafico.setMaxSize(parametriConfigurazione.larghezzaGrafico
       ,parametriConfigurazione.altezzaGrafico);
          });
  }
  
  public void cercaTavoliBiblioteca() {  //7)
      ig.cercaTavoli.setOnAction((ActionEvent ev) -> { 
           DateTimeFormatter formatter = DateTimeFormatter.
               ofPattern("yyyy-MM-dd HH:mm:ss z",Locale.ITALY).withZone(ZoneId.of("Europe/Rome"));
          LocalDateTime oggi = LocalDateTime.now(); 
              formatter = formatter.withLocale(Locale.ITALIAN);
          String timestamp = oggi.format(formatter); 
          EventoUtente e = new EventoUtente("PrenotazioneBiblioteca","localhost",timestamp, "Cerca"); 
      inviaEventoUtente.inviaEvento(e);
           richiestaUtente.inizializzaTabella(); }); 
  }
  
  public void statoChiusuraBiblioteca(Stage stage) {  //8)
       stage.setOnCloseRequest((WindowEvent we) -> {  
            cacheDati.salvaDatiInCache();
            DateTimeFormatter formatter = DateTimeFormatter.
                ofPattern("yyyy-MM-dd HH:mm:ss z",Locale.ITALY).withZone(ZoneId.of("Europe/Rome"));
          LocalDateTime oggi = LocalDateTime.now(); 
              formatter = formatter.withLocale(Locale.ITALIAN);
          String timestamp = oggi.format(formatter); 
          EventoUtente e = new EventoUtente("PrenotazioneBiblioteca","localhost",timestamp, "TERMINA"); 
     inviaEventoUtente.inviaEvento(e);
         });
  }
  
}

/*
 ----------COMMENTI------------------
1) La classe si occupa di gestire gli eventi generati dall'utente sull'interfaccia grafica
   aggiornandola di conseguenza
2) i campi della classe sono riferimenti a classi che si occupano di effettuare 
   operazioni di basso livello come leggere da file. questo ci permette di separare 
   il back end dal front end
3) il metodo si occupa di inizializzare l'interfaccia grafica ottenedo i dati dalla cache 
   e ,usando la classe EseguiRichiestaUtente, dal database per costruire la tableview.
   si occupa di inviare l'evento di avvio dell'applicazione al server di log
4) il metodo serve per gestire l'evento che si verifica quando l'utente clicca su prenota. 
   Chiama il metodo aggiungiPrenotazione della classe EseguiRichiestaUtente per aggiungere 
   la prenotazione al database e invia l'evento al server di log usando il metodo 
   inviaEvento della classe InviaEventoAServerDiLog
5) il metodo serve per gestire l'evento che si verifica quando l'utente clicca su cancella. 
   Chiama il metodo cancellaPrenotazione della classe EseguiRichiestaUtente per cancellare 
   la prenotazione nel database e invia l'evento al server di log usando il metodo 
   inviaEvento della classe InviaEventoAServerDiLog
6) il metodo serve per gestire l'evento che si verifica quando l'utente clicca su confronta. 
   Chiama il metodo inizializzaDatiGrafico della classe EseguiRichiestaUtente per ottenere i 
   nuovi valori per inizializzare il grafico interrogando il database e invia l'evento al server di log usando il metodo 
   inviaEvento della classe InviaEventoAServerDiLog
7)  il metodo serve per gestire l'evento che si verifica quando l'utente clicca su confronta. 
   Chiama il metodo inizializzaTabella della classe EseguiRichiestaUtente per ottenere i 
   nuovi valori per inizializzare la tableview interrogando il database e invia l'evento al server di log usando il metodo 
   inviaEvento della classe InviaEventoAServerDiLog
8)  il metodo serve per gestire l'evento che si verifica quando l'utente chiude l'applicazione. 
    si occupa di salvare i dati in cache usando la classe CachePrenotazioneBiblioteca e invia 
    l'evento di terminazione dell'applicazione al server di log usando la classe 
   InviaEventoAServerDiLog






*/