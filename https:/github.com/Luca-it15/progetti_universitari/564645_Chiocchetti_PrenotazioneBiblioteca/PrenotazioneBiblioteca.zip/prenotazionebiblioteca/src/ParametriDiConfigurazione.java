import java.io.*; 

public class ParametriDiConfigurazione implements Serializable { //1)
    public String indirizzoIpClient; 
    public String indirizzoIpServerDiLog; 
    public int portaServerLog; 
    public String indirizzoIpDatabase; 
    public int portaDatabase; 
    public String usernameDatabase; 
    public String passwordDatabase; 
    public String fontCaratteri; 
    public double  altezzaGrafico; 
    public double  larghezzaGrafico; 
    public String  coloreSfondo; 
    public String turni0; 
    public String turni1; 
    public String turni2; 
    public int intervalloGiorniDefault;
    public int annoDiConfrontoDefault; 
    public String coloriLegenda0;
    public String coloriLegenda1;
    public String coloriLegenda2;
    public GestoreXML gestoreXML; 
    
    public ParametriDiConfigurazione() {
        gestoreXML = new GestoreXML();  
        ParametriDiConfigurazione pdc = gestoreXML.recuperaParametriConfigurazione(); //2)
         this.indirizzoIpClient = pdc.indirizzoIpClient;
         this.indirizzoIpServerDiLog =  pdc.indirizzoIpServerDiLog; 
         this.portaServerLog = pdc.portaServerLog; 
         this.indirizzoIpDatabase = pdc.indirizzoIpDatabase; 
         this.portaDatabase = pdc.portaDatabase; 
         this.usernameDatabase = pdc.usernameDatabase; 
         this.passwordDatabase = pdc.passwordDatabase; 
         this.fontCaratteri = pdc.fontCaratteri; 
         this.altezzaGrafico = pdc.altezzaGrafico; 
         this.larghezzaGrafico = pdc.larghezzaGrafico; 
         this.coloreSfondo = pdc.coloreSfondo; 
         this.turni0 = pdc.turni0; 
         this.turni1 = pdc.turni1; 
         this.turni2 = pdc.turni2;
         this.intervalloGiorniDefault = pdc.intervalloGiorniDefault;
         this.annoDiConfrontoDefault = pdc.annoDiConfrontoDefault; 
         this.coloriLegenda0 = pdc.coloriLegenda0; 
         this.coloriLegenda1 = pdc.coloriLegenda1;
         this.coloriLegenda2 = pdc.coloriLegenda2; 
    }
}

/*
 ----------COMMENTI------------------
1) la classe ParametriDiConfigurazione implementa l'interfaccia Serializable in 
   modo da dire alla JVM che è una classe serializzabile e può essere inviata tramite 
   socket in formato XML. 
   infatti la classe viene costruita leggendo il file XML e convertendolo in un oggetto
   di tipo ParametriDiConfigurazione
2) Per le operazioni che coinvolgono l'XML si usa GestoreXML, quindi istanziamo un oggetto 
   di quella classe e usiamo i suoi metodi nel costruttore per recuperare i valori dal file 
   e inizializzare i campi della classe 
*/