/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.time.*;
import java.time.format.*;
import javafx.application.*;
import javafx.collections.*;
import javafx.event.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.chart.*;
import javafx.scene.control.*; 
import javafx.scene.control.cell.*;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.stage.*;

/**
 *
 * @author Luca
 */
 public class PrenotazioneBibliotecaGUI extends Application { //1)
 public Label nomeUtente; 
 public TextField campoNomeUtente; 
 public Label data; 
 public DatePicker calendario; 
 public Label turno; 
 public ComboBox turnoLista; 
 public ObservableList<String> elementoTurno; 
 public Button cercaTavoli; 
 public Label tavoli; 
 public TableView<StatoTavoloGiorno> tabellaTavoli ; 
 public ObservableList<StatoTavoloGiorno> listaTavolo; 
 public Label nomeApplicazione; 
 public Button prenota; 
 public Button cancella; 
 public TextField titoloLibro; 
 public Label legenda;
 public Rectangle[] coloriLegenda; 
 public Label[] nomiLegenda; 
 public Label graficoPrenotazioni; 
 public Label campoDa; 
 public DatePicker dataDa; 
 public Label campoA; 
 public TextField dataA; 
 public Label campoConfrontaAnno; 
 public ComboBox annoConfronto; 
 public Button confronta; 
 public LineChart<String, Number> grafico; 
 public XYChart.Series lineaGraficoCorrente; 
 public XYChart.Series lineaGraficoPassato; 
 public EseguiRichiestaUtente richiestaUtente; 
 public GestoreBiblioteca gestoreBiblioteca; 
 
 
 public void start(Stage stage) { //2)
  
  inizializzaCampi(); //3)
  final VBox vboxgeneral = new VBox(); 
  final VBox vtable = new VBox(); 
  final VBox vinfo = new VBox(); 
  vinfo.setPadding(new Insets(10, 0, 0,10));
  vinfo.setSpacing(5);
  vinfo.getChildren().addAll(nomeUtente,
          campoNomeUtente,data,calendario,  turno, turnoLista, cercaTavoli); 
  inizializzaTabella();  //4)
  HBox hbutton = new HBox(); 
  hbutton.setPadding(new Insets(10, 0, 0, 10));
  hbutton.setSpacing(20); 
  hbutton.getChildren().addAll(prenota, cancella);
  vtable.getChildren().addAll(tavoli, tabellaTavoli,hbutton); 
  vtable.setPadding(new Insets(10, 0, 0, 10));
  vboxgeneral.setPadding(new Insets(10, 0, 0, 10));
  final HBox hbox1 = new HBox(); 
  hbox1.setPadding(new Insets(10,0,0,10)); 
  hbox1.getChildren().addAll(vinfo,vtable); 
  VBox vgrafico = inizializzaGrafico(); //5)
  vboxgeneral.getChildren().addAll(nomeApplicazione,hbox1, vgrafico); 
  vboxgeneral.setAlignment(Pos.CENTER);
  
  ScrollPane scrollpane = new ScrollPane(vboxgeneral); //5) 
  scrollpane.setPrefSize(1280, 900);
  Scene scene = new Scene(new Group(scrollpane)); 
  String css = this.getClass().getResource("stile.css").toExternalForm(); //7)
  scene.getStylesheets().add(css); 
  stage.setTitle("Prenotazione Biblioteca"); 
  tabellaTavoli.setMinWidth(900); 
  tabellaTavoli.setMaxHeight(350); 
  associaEventi(stage,vgrafico); //8)
  gestoreBiblioteca.inizializzaDatiBiblioteca();  //9)
  stage.setScene(scene);
  stage.show();
 } 

  public void inizializzaCampi() { //3)
    richiestaUtente = new EseguiRichiestaUtente(this); 
    gestoreBiblioteca = new GestoreBiblioteca(this);   
    tavoli = new Label("Tavoli"); 
    tavoli.setStyle("-fx-font-family: " + 
            gestoreBiblioteca.parametriConfigurazione.fontCaratteri);
    tavoli.getStyleClass().add("sottotitolo"); 
    nomeApplicazione = new Label("Prenotazione Biblioteca"); 
    nomeApplicazione.setStyle("-fx-font-family: " + 
      gestoreBiblioteca.parametriConfigurazione.fontCaratteri);
    nomeApplicazione.getStyleClass().add("titolo"); 
    nomeUtente =  new Label("Nome Utente"); 
    nomeUtente.setStyle("-fx-font-family: " + 
       gestoreBiblioteca.parametriConfigurazione.fontCaratteri);
    nomeUtente.getStyleClass().add("etichette");
    campoNomeUtente = new TextField("mario rossi");
      creaListaTurno();  //10)
    data = new Label("Data"); 
    data.setStyle("-fx-font-family: " + 
      gestoreBiblioteca.parametriConfigurazione.fontCaratteri);
    data.getStyleClass().add("etichette");  //11)
    calendario = new DatePicker(LocalDate.now());
    cercaTavoli = new Button("Cerca"); 
    cercaTavoli.setStyle("-fx-font-family: " + 
      gestoreBiblioteca.parametriConfigurazione.fontCaratteri);
    cercaTavoli.getStyleClass().add("bottoni"); 
    prenota = new Button("Prenota"); 
    prenota.setStyle("-fx-font-family: " + 
      gestoreBiblioteca.parametriConfigurazione.fontCaratteri); 
    prenota.getStyleClass().add("bottoni"); //11)
    cancella = new Button("Cancella");
    cancella.setStyle("-fx-font-family: " + 
      gestoreBiblioteca.parametriConfigurazione.fontCaratteri);
    cancella.getStyleClass().add("cancella");  //11)
   
  }
  
  public void creaListaTurno() { //10)
   turno = new Label("Turno");
   turno.getStyleClass().add("etichette");
   elementoTurno = FXCollections.observableArrayList( 
      gestoreBiblioteca.parametriConfigurazione.turni0, 
      gestoreBiblioteca.parametriConfigurazione.turni1, 
      gestoreBiblioteca.parametriConfigurazione.turni2
   ); 
   turnoLista = new ComboBox(elementoTurno);
   turnoLista.setValue("Intero"); 
  }
 
  
  public VBox inizializzaLegenda() { //12)
   legenda = new Label("Legenda                    "); 
   legenda.getStyleClass().add("etichette"); 
   coloriLegenda = new Rectangle[3];
   coloriLegenda[0] = new Rectangle(20, 20);
   coloriLegenda[1] = new Rectangle(20,20); 
   coloriLegenda[2] = new Rectangle(20, 20);
  
   coloriLegenda[0].setStyle("-fx-fill: " + 
      gestoreBiblioteca.parametriConfigurazione.coloriLegenda0 + 
                                       "; -fx-stroke: black;");
   System.out.println(
           gestoreBiblioteca.parametriConfigurazione.coloriLegenda0);
   coloriLegenda[1].setStyle("-fx-fill: " + 
           gestoreBiblioteca.parametriConfigurazione.coloriLegenda1 +
                                  "; -fx-stroke: black;"); 
   coloriLegenda[2].setStyle("-fx-fill: "+ 
           gestoreBiblioteca.parametriConfigurazione.coloriLegenda2 +
                                ";-fx-stroke: black;");
   nomiLegenda = new Label[3]; 
   nomiLegenda[0] = new Label(" Disponibile                 "); 
   nomiLegenda[1] = new Label(" Non Disponibile         "); 
   nomiLegenda[2] = new Label(" Prenotato dall'utente "); 
   nomiLegenda[0].getStyleClass().add("legenda"); 
   nomiLegenda[1].getStyleClass().add("legenda"); 
   nomiLegenda[2].getStyleClass().add("legenda"); 
   HBox hleg0 = new HBox(); 
   hleg0.getChildren().addAll(coloriLegenda[0], nomiLegenda[0]); 
   hleg0.setStyle("-fx-alignment: top-right");
  
  HBox hleg1 = new HBox(); 
  hleg1.getChildren().addAll(coloriLegenda[1], nomiLegenda[1]); 
  hleg1.setStyle("-fx-alignment: top-right");
  
  HBox hleg2 = new HBox(); 
  hleg2.getChildren().addAll(coloriLegenda[2], nomiLegenda[2]); 
  hleg2.setStyle("-fx-alignment: top-right");
  
  VBox vlegenda = new VBox(); 
  vlegenda.setPadding(new Insets(10, 0, 0,10));
  vlegenda.getChildren().addAll(legenda,hleg0, hleg1, hleg2); 
  vlegenda.setStyle("-fx-alignment: top-right"); 
  return vlegenda; 
  }
  
  
  public void associaEventi(Stage stage, VBox vgrafico) { //8)
        gestoreBiblioteca.prenotaPostoBiblioteca();
        gestoreBiblioteca.disdiciPostoBiblioteca();
        gestoreBiblioteca.cercaTavoliBiblioteca();
        gestoreBiblioteca.confrontaDateGrafico(vgrafico);
        gestoreBiblioteca.statoChiusuraBiblioteca(stage);    
      }
    
  public void inizializzaZonaGrafico() { //13) 
      graficoPrenotazioni = new Label("Grafico Prenotazioni"); 
      graficoPrenotazioni.getStyleClass().add("sottotitolo"); 
      confronta = new Button("Confronta"); 
      confronta.getStyleClass().add("bottoni"); 
      campoDa = new Label("DA"); 
      campoDa.getStyleClass().add("etichette"); 
      LocalDate oggi = LocalDate.now(); 
      int intervallo = 
              gestoreBiblioteca.parametriConfigurazione.intervalloGiorniDefault;  
      LocalDate scorsaSettimana = oggi.minusDays(intervallo); 
      dataDa = new DatePicker(scorsaSettimana); 
      campoA = new Label("A"); 
      campoA.getStyleClass().add("etichette"); 
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
      dataA = new TextField(oggi.format(formatter)); 
      dataA.setEditable(false);
      campoConfrontaAnno = new Label("Confronta con anno"); 
      campoConfrontaAnno.getStyleClass().add("etichette"); 
      LocalDate scorsoAnno = LocalDate.now(ZoneId.systemDefault());
      ObservableList<String> selectableYears = FXCollections.observableArrayList(); 
      int anno = scorsoAnno.getYear(); 
      int annoRemoto = anno - 10; 
      for(int i = annoRemoto; i < anno; i++){
          selectableYears.add(Integer.toString(i)); 
      }
      int annoConfrontoDefault = anno - 
              gestoreBiblioteca.parametriConfigurazione.annoDiConfrontoDefault; 
      annoConfronto = new ComboBox<>(selectableYears);
      annoConfronto.setValue(Integer.toString(annoConfrontoDefault));
  } 
      
  public void inizializzaTabella() { //4)
      tabellaTavoli = new TableView<>(); 
      TableColumn tavolo = new TableColumn("Tavolo"); 
      tavolo.setCellValueFactory(new PropertyValueFactory<>("tavolo"));
      tabellaTavoli.setStyle("-fx-background-color: " + 
               gestoreBiblioteca.parametriConfigurazione.coloreSfondo + ";"); 
     TableColumn disp = new TableColumn("Disponibilita"); 
     disp.setCellValueFactory(new PropertyValueFactory<>("disponibilita"));
     disp.setPrefWidth(200);
  
     TableColumn tipo = new TableColumn("Tipo"); 
     tipo.setCellValueFactory(new PropertyValueFactory<>("tipo"));
     tipo.setPrefWidth(200);
  
     TableColumn libro = new TableColumn("Libro"); 
     libro.setCellValueFactory(new PropertyValueFactory<>("libro"));  
     tabellaTavoli.getColumns().addAll(tavolo, disp, tipo, libro);
     libro.setPrefWidth(360);
  }
  
   public VBox inizializzaGrafico() { //6)
      inizializzaZonaGrafico(); //13)
      HBox linea1 = new HBox(); 
      linea1.setPadding(new Insets(10, 0, 0, 10));
      linea1.setSpacing(10); 
      HBox linea2 = new HBox(); 
      linea2.setPadding(new Insets(10, 0, 0, 10));
      linea2.setSpacing(10); 
      linea2.getChildren().addAll(campoConfrontaAnno, annoConfronto, confronta); 
      VBox vlegenda = inizializzaLegenda(); 
      linea1.getChildren().addAll(campoDa, dataDa, campoA, dataA);
      VBox date = new VBox(); 
      date.setPadding(new Insets(10, 0, 0, 10));
      date.setSpacing(20); 
      date.getChildren().addAll(graficoPrenotazioni,linea1, linea2);
      HBox middle = new HBox(); 
      middle.setPadding(new Insets(10, 0, 0, 10));
      middle.setSpacing(200); 
      middle.getChildren().addAll(date, vlegenda); 
      VBox vgrafico = new VBox(); 
      vgrafico.setPadding(new Insets(10, 0, 0, 10));
      vgrafico.setSpacing(30);
      richiestaUtente.inizializzaDatiGrafico(); //14)
      vgrafico.getChildren().addAll(middle, grafico); 
      grafico.setMaxSize(gestoreBiblioteca.parametriConfigurazione.larghezzaGrafico
      , gestoreBiblioteca.parametriConfigurazione.altezzaGrafico);
      return vgrafico; 
   }
           
}

   
/*
 ----------COMMENTI------------------
1) La classe PrenotazioneBibliotecaGUI estende la classe Application per poterne ereditare i metodi, 
   come ad esempio il metodo start
2) Ridefinisco il metodo start in modo tale da poter costruire l'interfaccia grafica dell'applicazione.
   il metodo start funziona anche come punto di ingresso per il programma
3) metodo che serve per inizializzare tutti i campi presenti nella classe PrenotazioneBibliotecaGUI.
   Mbbiamo scelto di separare le inizializzazioni dal metodo start per poterne avere un maggior focus
   e di rendere piu semplice una futura manutenzione.
4) Metodo che serve per inizializzare la TableView tabellaTavoli dell'interfaccia grafica 
5) Datiamo la nostra interfaccia grafica di una barra laterale in modo tale da poter scorrere la schermata.
   questa scelta è dovuta al fatto che l'interfaccia è costituita da molti elemementi
6) Metodo che serve per creare ed inizializzare il grafico dell'interfaccia grafica. 
7) Assegniamo alla scena un foglio di stile css in modo da evitare le troppe righe di codice 
   che servirebbero per avere lo stile desiderato 
8) Raccogliamo i metodi per la gestione degli eventi in uno metodo all'interno della classe 
   PrenotazioneBibliotecaGUI.
9) Il metodo si occupa di inizializzare tutti i dati relativi alla biblioteca all'avvio invocando 
  gli opportuni metodi.  Esegue le seguenti azioni: 
   - inizializza i campi relativi all'informazioni della prenotazione prendendoli dal file di cache
   - crea la tabella dei tavoli 
   - inizializza la tabella con le relative informazioni contenute nella cache 
   - invia al server di log l'evento di avvio dell'applicazione
10) Il metodo inizializza la ObservableList elementoTurno con i valori Intero, Mattina, Pomeriggio.
11) Assegniamo agli elementi dell'interfaccia grafica le relative classi css per ottenere lo 
    stile voluto. 
12) Il metodi si occupa di realizzare la legenda presente nell'interfaccia grafica. 
    i valori della legenda sono i seguenti: 
    - Disponibile 
    - Non Disponibile
    - Prenotato dall'utente 
13) il metodo si occupa di inizializzare la zona dell'interfaccia occupata dal grafico 
    posizionando gli elementi nell'ordine voluto 
*/