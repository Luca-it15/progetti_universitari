
import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.*;
import java.util.*;

public class CachePrenotazioneBiblioteca { //1) 
    private PrenotazioneBibliotecaGUI interfacciaGrafica; 
    private final String path; 
    private List<String> datiDaCaricare;  
    private int posizione; 
     
    public CachePrenotazioneBiblioteca(PrenotazioneBibliotecaGUI interfaccia){
        this.interfacciaGrafica = interfaccia; 
        path = "./myfiles/fileDiCache.txt"; 
        datiDaCaricare = new ArrayList<>();
        posizione = 0; 
    }
    
 public void salvaDatiInCache() { //2) 
    LocalDate data = interfacciaGrafica.calendario.getValue(); 
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    LocalDate dataConfronto = interfacciaGrafica.dataDa.getValue(); 
    DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd/MM/yyyy"); 
    List<String> datiDaSalvare = new ArrayList<>(); 
    datiDaSalvare.add(interfacciaGrafica.campoNomeUtente.getText());
    datiDaSalvare.add(data.format(formatter)); 
    datiDaSalvare.add((String)interfacciaGrafica.turnoLista.getValue()); 
    datiDaSalvare.add(dataConfronto.format(formatter1)); 
    datiDaSalvare.add((String)interfacciaGrafica.annoConfronto.getValue()); 
    if(interfacciaGrafica.listaTavolo != null) { 
    StatoTavoloGiorno stg = interfacciaGrafica.tabellaTavoli.getSelectionModel().getSelectedItem(); 
     if(stg != null) {
     datiDaSalvare.add(Integer.toString(stg.getTavolo())); 
     datiDaSalvare.add(stg.getLibro().getText()); 
     }
    }
    try {
        Files.write(Paths.get(path), datiDaSalvare);
     }catch(IOException e) {
        System.err.println("Errore!!!!!" + e.getMessage());
      }
 }
 
 public void caricaDatiDaCache() { //3) 
    try { 
      datiDaCaricare = Files.readAllLines(Paths.get(path)); 
      System.out.println(datiDaCaricare.size());
      if(datiDaCaricare.size() != 0) {
        interfacciaGrafica.campoNomeUtente.setText(datiDaCaricare.get(0));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        formatter = formatter.withLocale(Locale.FRENCH); 
        LocalDate data = LocalDate.parse(datiDaCaricare.get(1), formatter);
        interfacciaGrafica.calendario.setValue(data); 
        interfacciaGrafica.turnoLista.setValue(datiDaCaricare.get(2));
        DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        formatter1 = formatter1.withLocale(Locale.FRENCH); 
        LocalDate dataConfronto = LocalDate.parse(datiDaCaricare.get(3), formatter1);
        interfacciaGrafica.dataDa.setValue(dataConfronto); 
        interfacciaGrafica.annoConfronto.setValue(datiDaCaricare.get(4));
       if(datiDaCaricare.size() > 5) {
         int pos = (Integer.parseInt(datiDaCaricare.get(5)) - 1); 
         posizione = pos;
        }
        System.out.println(interfacciaGrafica.campoNomeUtente.getText()); 
       }
      }catch( IOException ex) {
       System.err.println("Errore!! " + ex.getMessage()); 
    }
  }
  public void caricaDatiCacheInTabella() { //4) 
      System.out.println(posizione); 
      if(posizione != 0) {
         interfacciaGrafica.tabellaTavoli.getSelectionModel().select(posizione);
       if(interfacciaGrafica.listaTavolo != null && datiDaCaricare.size() > 6) {
        StatoTavoloGiorno stg = interfacciaGrafica.tabellaTavoli.getSelectionModel().getSelectedItem(); 
        stg.getLibro().setText(datiDaCaricare.get(6));
      }
     }   
   } 
}

/*
 ----------COMMENTI------------------
1) La classe si occupa di salvare i dati in cache e di usarli per inizializzare l'interfaccia grafica
2) il metodo ci permette di salvare i dati in cache. salviamo i dati relativi all'ultimo utilizzo: 
  - Il nome utente 
  - la data
  - il turno 
  - il tavolo selezionato se presente
  - il libro inserito se presente
  - la data di inizio intervallo per il confronto 
  - l'anno di confronto 
3) il metodo ci permette di caricare i dati da cache per inizializzare l'interfaccia grafica
*  tranne la tabella che verrà inizializzata in un secondo momento. 
4) al momento del caricamento iniziale dei dati della cache, la tabella dei tavoli non è ancora correttamente
  inizializzata, quindi usiamo i dati della cache relativi alla tabella per inizializzarla in un secondo momento
*/
