import java.io.*;
import java.util.*;

public class EventoUtente implements Serializable {  //1) 
    private String nomeApplicazione; 
    private String indirizzoIpClient; 
    private String timeStamp; 
    private String evento; 
    public EventoUtente(String nomeApplicazione, String indirizzoIpClient,
                                              String timeStamp,String evento) {
        this.nomeApplicazione = nomeApplicazione; 
        this.indirizzoIpClient = indirizzoIpClient;
        this.timeStamp = timeStamp; 
        this.evento = evento; 
    } 
}

/*
 ----------COMMENTI------------------
1) la classe implementa l'interfaccia serializable per segnalare che la classe deve 
   poter essere serializzabile. 
   la classe rappresenta l'evento generato dall'utente e viene inviato al server di log 
   tramite la classe InviaEventoAServerDiLog
*/