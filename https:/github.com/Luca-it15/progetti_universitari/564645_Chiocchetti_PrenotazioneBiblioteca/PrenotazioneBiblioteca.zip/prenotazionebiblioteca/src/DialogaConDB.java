
import java.sql.*;
import java.time.*;
import java.util.*; 
import javafx.collections.*; 

public class DialogaConDB {
    private final String pathDB; 
    private final String usernameDB; 
    private final String passwordDB; 
    ParametriDiConfigurazione pdc; 
    public DialogaConDB() {  
        pdc = new ParametriDiConfigurazione(); //1) 
        pathDB = new String("jdbc:mysql://" + 
                pdc.indirizzoIpDatabase + ":" + 
                pdc.portaDatabase + "/biblioteca" ); 
        usernameDB = new String(pdc.usernameDatabase); 
        passwordDB = new String(pdc.passwordDatabase);   
    }
    public String getPathDB() {
        return pathDB; 
    }
    public String getUsernameDB() {
        return usernameDB; 
    }
    public String getPasswordDB() {
        return passwordDB; 
    }
    public ObservableList<StatoTavoloGiorno> inizializzaTabellaTavoliDB(String nomeUtente, String data, String turno) { //2) 
     ObservableList<StatoTavoloGiorno> listaTavolo = FXCollections.observableArrayList(); 
      int[] tavoli = new int[16]; 
      String[] nomi = new String[16];
      String[] libri = new String[16];
      String[] arrayTurno = new String[16];  
      try( Connection co = DriverManager.getConnection(getPathDB(),getUsernameDB(), getPasswordDB());) {  
        try(PreparedStatement ps1 = co.prepareStatement("SELECT * FROM prenotazioni WHERE dataPrenotazione = ? order by idtavolo"); 
        ) { 
          ps1.setString(1, data);
          ResultSet rs = ps1.executeQuery(); 
         int i = 0; 
         while(rs.next()) { 
         tavoli[i] = rs.getInt("idtavolo"); 
         nomi[i] = rs.getString("nomeUtente"); 
         libri[i] = rs.getString("libro"); 
         arrayTurno[i] = rs.getString("turno"); 
         i++; 
          }
        } catch(SQLException e) {
        System.err.println(e.getMessage()); 
         }   
         try(Statement st = co.createStatement(); ) {
            ResultSet rs1 = st.executeQuery("SELECT * FROM tavoli"); 
            int j = 0; 
            while(rs1.next()) { 
              if(rs1.getInt("idtavolo") == tavoli[j]) {
                if(arrayTurno[j].equals("Intero") || arrayTurno[j].equals(turno) || turno.equals("Intero")) {  
                  listaTavolo.add(new StatoTavoloGiorno(rs1.getInt("idtavolo"),false,rs1.getString("tipo"),nomeUtente ,nomi[j],libri[j])); 
                  j++; 
                  continue; 
                 } 
                 j++;  
              }
        listaTavolo.add(new StatoTavoloGiorno(rs1.getInt("idtavolo"),true,rs1.getString("tipo"), nomeUtente,null,null)); 
       }  
    } catch(SQLException e) {
        System.err.println(e.getMessage());
    }       
  }catch(SQLException e) {
        System.err.println(e.getMessage()); 
   }
      return listaTavolo; 
  }
    
    public boolean aggiungiPrenotazioneDB(String nomeUtente, String data, String turno, int tavolo, String tipo, String libro){ //3)
      boolean conferma = false; 
      try( Connection co = DriverManager.getConnection(getPathDB(), getUsernameDB(), getPasswordDB());) {  
        try(PreparedStatement ps = co.prepareStatement("SELECT * FROM prenotazioni WHERE dataPrenotazione = ? order by idtavolo"); 
        ) { 
          ps.setString(1, data);
          ResultSet rs = ps.executeQuery(); 
            while(rs.next()) { 
              if(rs.getString("libro") != null && rs.getString("libro").equals(libro)) 
               return conferma; 
           }
        } catch(SQLException e) {
        System.err.println(e.getMessage());
        }
      try(PreparedStatement ps1 = co.prepareStatement("INSERT INTO prenotazioni VALUES(?, ?, ?, ?, ?, ?)");)
      { 
        ps1.setString(1, nomeUtente);
        ps1.setString(2, data);
        ps1.setString(3, turno); 
        ps1.setInt(4, tavolo);
        ps1.setString(5, tipo);
        ps1.setString(6, libro);
        int rs = ps1.executeUpdate(); 
        if(rs != 1) {
           System.err.println("Errore nell'inserimenteo");
        } else 
           conferma = true; 
      }catch(SQLException e) {
         System.err.println(e.getMessage());
     }    
    }       
     catch(SQLException e) {
         System.err.println(e.getMessage());
     }
      return conferma; 
    }  
    
    public boolean cancellaPrenotazioneDB(String nomeUtente, String data, String turno){ //4) 
      boolean conferma = false; 
      try( Connection co = DriverManager.getConnection(getPathDB(), getUsernameDB(), getPasswordDB());
          PreparedStatement ps1 = co.prepareStatement("DELETE FROM prenotazioni WHERE nomeUtente = ? AND dataPrenotazione = ? AND turno =  ?");)
       { 
        ps1.setString(1, nomeUtente);
        System.out.println(nomeUtente);
        ps1.setString(2, data);
        System.out.println(data);
        ps1.setString(3, turno); 
           System.out.println(turno);
        int rs = ps1.executeUpdate(); 
        if(rs != 1) {
           System.err.println("Errore nella cancellazione");
        } else 
           conferma = true; 
      }catch(SQLException e) {
         System.err.println(e.getMessage());
     }           
      return conferma; 
    }      

    public int numeroPrenotazioni(String data) {  //5) 
        try( Connection co = DriverManager.getConnection(getPathDB(), getUsernameDB(), getPasswordDB());
          PreparedStatement ps1 = co.prepareStatement("SELECT count(*) as risultato FROM prenotazioni WHERE dataPrenotazione = ?");)
       { 
        ps1.setString(1, data); 
        ResultSet rs = ps1.executeQuery();  
         rs.next();
         int ris = rs.getInt("risultato"); 
         return ris; 
      }catch(SQLException e) {
         System.err.println(e.getMessage());
     }           
      return 0;  
    }      
}

/*
 ----------COMMENTI------------------
1) I parametri relativi alla connessione da effettuare con il database 
   vengono presi dal file di configurazione utilizzando la classe ParametriDiConfigurazione
2) il metodo ci permette di interrogare il database e di ricavare le prenotazioni effettuate
   tramite i valori delle prenotazioni andiamo a creare oggetti di tipo StatoTavoloGiorno.
   il metodo restituisce un ObservableArrayList di tipo StatoTavoloGiorno. 
3) il metodo ci permette di aggiungere una prenotazione al database 
   i presuppone che l'utente non cerchi di prenotare un posto non disponibile quindi il risultato restituito 
   fa riferimento alla disponibilita del libro, in quanto negli altri casi la prenotazione va a buon fine, 
   salvo errori non dovuti all'utente come la disconnessione con il database.
4) il metodo ci permette di cancellare una prenotazine dal database. 
   cancelliamo la prenotazione dell'utente facendoci passare come argomenti: nomeUtente, data, turno che formano la chiave primaria
   all'interno della tabella prenotazioni, il valore di ritorno mi dirà se la cancellazione è andata a buon fine 
5) il metodo ci permette di ottenere il numero di prenotazioni per un dato giorno in modo da 
   poter usare il dato per inizializzare il grafico.
    
*/
