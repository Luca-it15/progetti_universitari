
import com.thoughtworks.xstream.*;
import java.io.*;
import java.nio.file.*; 
import javax.xml.*;
import javax.xml.parsers.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import javax.xml.validation.*;
import org.w3c.dom.*;
import org.xml.sax.*;

public class GestoreXML { //1)
   public boolean validaFileXML(String pathXML, String pathXSD) { //2)
    try { 
      DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder(); 
      SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
      Document d = db.parse(new File(pathXML)); 
      Schema s = sf.newSchema(new StreamSource(new File(pathXSD)));
      s.newValidator().validate(new DOMSource(d)); 
      return true; 
      } catch (Exception e) { 
       if (e instanceof SAXException) 
        System.out.println("Errore di validazione: " + e.getMessage()); 
      else
        System.out.println(e.getMessage()); 
     } 
      return false; 
    }  
   
   public ParametriDiConfigurazione recuperaParametriConfigurazione() { //3)
    XStream xs = new XStream(); 
    if(validaFileXML("./myfiles/parametriDiConfigurazione.xml","./myfiles/parametriDiConfigurazione.xsd" )) {
     try { String  x = new String(Files.readAllBytes(Paths.get("./myfiles/parametriDiConfigurazione.xml")));
           return (ParametriDiConfigurazione)xs.fromXML(x);
     } catch (Exception e) {
         System.err.println("Errore!!: " + e.getMessage());  
           return null; 
      } 
    }
     else return null; 
   } 
   
   public String convertiInXML( EventoUtente e) { //4)
       return (new XStream().toXML(e)); 
   }
   
   public void aggiungiALog(String evento) {  //5) 
      try {
          System.out.println("aggiungo al file di log: " + evento); 
          Files.write(Paths.get("./myfiles/fileDiLog.txt"), evento.getBytes(), StandardOpenOption.APPEND); 
           String x = "      \n\n"; 
            Files.write(Paths.get("./myfiles/fileDiLog.txt"), x.getBytes(), StandardOpenOption.APPEND);
          
      }catch(IOException e) { e.printStackTrace(); } 
   }
}

/*
 ----------COMMENTI------------------
1) La classe GestoreXML viene utilizzata per svolgere le operazioni che rigurdano l'XML 
   evitando ridondanze di codice all'interno del progetto
2) il metodo validaFileXML prende in ingresso due path di file relativi al file XML e al 
   suo XSD, valida il file XML usando il file XSD. 
   nel caso della validazione del file di log, essa non può avvenire perche il file non presenta
  tag di chiusura o di apertura,abbiamo scelto di scrivere il contenuto che vogliamo aggiungere 
  nel file di log quindi un oggetto di tipo EventoUtente in formato XML dentro a un file 
  di appoggio e poi usando un file XSD che ne contiene la grammatica, lo possiamo validare.
3) il metodo ci permette di recuperare i parametri di configurazione che sono contenuti nel file 
   parametriDiConfigurazione.xml. 
4) permette la conversione di un oggetto ti tipo EventoUtente in una stringa XML
5) questo metodo ci permette di scrivere in append sul file di log la stringa evento passata 
   come argomento

*/