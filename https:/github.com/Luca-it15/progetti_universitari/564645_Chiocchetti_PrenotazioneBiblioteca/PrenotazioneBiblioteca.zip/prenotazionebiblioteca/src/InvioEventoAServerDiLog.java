
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.logging.*;


public class InvioEventoAServerDiLog { //1)
    private GestoreXML gestoreXML;  //2)
    private ParametriDiConfigurazione pdc;  //3)
    
    public InvioEventoAServerDiLog() { 
        this.gestoreXML = new GestoreXML(); 
        pdc = new ParametriDiConfigurazione(); 
    }
  
    public void inviaEvento(EventoUtente e) {  //4)
        try( Socket sock = new Socket(pdc.indirizzoIpServerDiLog,pdc.portaServerLog); 
             DataOutputStream dos = 
               new DataOutputStream(sock.getOutputStream()); 
          ){ 
             String x = gestoreXML.convertiInXML(e); 
              dos.writeUTF(x); 
           } catch(IOException ex) { System.err.println(ex.getMessage()); }
          System.out.println("invio al server: " + gestoreXML.convertiInXML(e) );  
    }   
    
}

/*
 ----------COMMENTI------------------
1) La classe si preoccupa di inviare al server di log, gli eventi che vengono 
   generati dall'utente in formato xml
2) per la gestione dei file xml si utilizza la classe GestoreXML
3) per recuperare le informazioni del server di log: indirizzo IP e porta, si 
   utilizza la classe ParametriDiConfigurazione
4) il metodo serve per inviare al server di log l'evento generato dall'utente in formato XML.
   La validazione dell'XML sarà fatto lato server, questo perche ci potrebbero essere dei problemi 
   durante l'invio e per ragioni di sicurezza. 






*/