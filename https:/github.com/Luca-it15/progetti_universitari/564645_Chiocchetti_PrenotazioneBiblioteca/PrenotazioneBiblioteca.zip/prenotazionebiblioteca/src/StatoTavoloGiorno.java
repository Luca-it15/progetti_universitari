
import javafx.beans.property.*;
import javafx.scene.control.*;
import javafx.scene.shape.*;


public  class StatoTavoloGiorno {
    private final SimpleIntegerProperty tavolo; //1)
    private final SimpleObjectProperty<Rectangle> disponibilita; //2)
    private final SimpleStringProperty tipo; 
    private final SimpleObjectProperty<TextField> libro; 
    public StatoTavoloGiorno(int tavolo, boolean disp, String tipo,String NomeUtente, String NomePrenotato, String libro) {
        this.tavolo = new SimpleIntegerProperty(tavolo); 
        this.disponibilita = new SimpleObjectProperty<>(); 
        this.tipo = new SimpleStringProperty(tipo); 
        Rectangle d = new Rectangle(20, 20); //3)
        TextField l = new TextField(libro);  //3)
        if(!disp) {
            if(NomeUtente.equals(NomePrenotato)) {
                 d.setStyle("-fx-fill: '0x8F00FF'");   
                 l.setStyle("-fx-text-fill: green");
            } else {
              d.setStyle("-fx-fill: red");  
            } 
             l.setEditable(false); 
        } else 
          d.setStyle("-fx-fill: green"); 
        this.disponibilita.set(d); 
      this.libro = new SimpleObjectProperty<>(); 
      this.libro.set(l); 
      
    }
    public int getTavolo() { return tavolo.get(); } //4)
    public Rectangle getDisponibilita() { return disponibilita.get(); } //4)
    public String getTipo() { return tipo.get(); }  //4)
    public TextField getLibro() { return libro.get(); } //4)
}

/*
 ----------COMMENTI------------------
1) per definire gli attributi della classe bean usiamo le classi del package javafx.beans.property,
   in tal modo, i bean saranno automaticamente dotati di osservabilità e di binding 
   con le alte classi di javafx(come le tableview) 
2) classe bean che ci permette di definire tipi di dato complessi che mantengono le stesse
   caratteristiche dei bean predefiniti. 
3) inizializziamo gli oggetti che poi andremo a inserire nei campi di tipi complessi della 
   classe bean
4) metodi utili per ritornare i valori dei campi della classe bean 



*/