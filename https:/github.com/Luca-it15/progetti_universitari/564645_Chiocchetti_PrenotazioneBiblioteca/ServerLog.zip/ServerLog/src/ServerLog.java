import java.net.*;
import java.io.*; 
import java.nio.file.Files;
import java.nio.file.Paths;


public class ServerLog {  //1) 
    private static GestoreXML x; 
    public static void main(String[] args) { 
      x = new GestoreXML(); 
      System.out.println("***************Server started***************");  
      try( ServerSocket servs = new ServerSocket(4243);) {
           while(true) {
               try(Socket sc = servs.accept(); 
                DataInputStream dis = 
                   new DataInputStream(sc.getInputStream()); 
                 ) {
                   String evento = dis.readUTF(); 
                    try {
                   Files.write(Paths.get("./myfiles/eventoUtente.xml"),evento.getBytes()); 
              } catch(IOException ex) { 
                 System.err.println(ex.getMessage()); 
               } 
               if(x.validaFileXML("./myfiles/eventoUtente.xml", "./myfiles/eventoUtente.xsd")) 
                   x.aggiungiALog(evento); 
               else 
              System.err.println("File xml non valido");
               } catch(IOException ex) { 
                   System.err.println( ex.getMessage()); 
              }
           }
         } catch(IOException ex) { 
              System.err.println( ex.getMessage()); 
           }       
        }
}
/*
 ----------COMMENTI------------------
1) la classe rappresenta il server di log, si mette in ascolto sulla porta 4243 e 
   e riceve gli eventi generati dall'utente in formato xml e li scrive su file.
   Prima di scrivere, si preoccupa di validare la stringa xml ricevuta che potrebbe 
   essere stata compromessa nell'invio. La sua validazione avviena scrivendo la stringa 
   ricevuta nel file eventoUtente.xml e usando il file eventoUtente.xsd che ne contiene la 
   grammatica
*/

