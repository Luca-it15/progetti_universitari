#include"../lib-1.0/costanti.c"
void signup_server(int i, fd_set* master){
int ret,  len;
uint16_t lmsg; //mi servirà per ottenere la lunghezza del messaggio
char username[DIM_MAX]; 
char password[DIM_MAX];  
char porta[DIM_PORTA];  
char path[DIM_PATH + DIM_MAX]; 
char dest[DIM_PATH + DIM_MAX + 12]; 
FILE* fd; 
FILE* fptr; 
char buffer[BUF_LEN];
char risposta[RESPONSE_LEN]; 
 
        fflush(stdout);
        /*operazione di registrazione del client 
        il client ci invierà il suo nome utente e la password e noi la salviamo su file in 
        modalita testo, se il nome utente non è gia presente nel file
        altrimenti diciamo all'utente che il suo nome utente è gia presente*/
        strcpy(buffer, "Richiesta di registazione\0"); 
        ret = send(i, (void*) buffer, strlen(buffer)+1, 0);
        if(ret < 0) {
         perror("Errore in fase di comunicazione: \n");
        }
        fflush(stdout); 
        //ricevo la dimensione dal client 
        ret = recv(i, (void*)&lmsg, sizeof(uint16_t), 0); //il device mi manderà la lunghezza del messaggio
        if(ret < 0) perror("Errore nella receive\n");   

        len = ntohs(lmsg); /*dimensione del messaggio che il server riceverà*/ 
        ret = recv(i, (void*)buffer, len, 0);
        /*controllo che il client non si sia disconesso, lo potrebbe fare in qualsiasi momento*/ 
        if(ret == 0){
        printf("CHIUSURA2 client rilevata!\n");
        fflush(stdout);
        // il client ha chiuso il socket, quindi
        // chiudo il socket connesso sul server
        close(i);
        // rimuovo il descrittore newfd da quelli da monitorare
         FD_CLR(i, master);
         }
        else if(ret < 0){
         perror("ERRORE! \n");
        // si è verificato un errore
         close(i);
         // rimuovo il descrittore newfd da quelli da monitorare
         FD_CLR(i, master);
         } else {  
             
          fptr = fopen("file_server/registrati.txt","a+"); 
           if(fptr == NULL) {
            printf("Errore nell'apertura del file\n"); 
            exit(1); 
           }

             sscanf(buffer,"%s %s %s",username, password, porta); 
             if(controllaUsername(fptr,username)) 
              strcpy(risposta, "Nome Utente gia usato, si prega di inserirne un altro\0");
             else {
              strcpy(risposta, "Registazione avvenuta\0");  
              fprintf(fptr,"%s\n", buffer); 
              //creo la cartella server dell'utente registrato
               sprintf(path, "utenti_server/%s_server/",username);
               mkdir(path, 0750); 

               sprintf(dest, "%smittenti.txt", path); 
               //creo il file mittenti.txt che conterrà il nome 
               //utente di chi ha inviato un messaggio a username 
               //quando era offline
               fd = fopen(dest, "w"); 
               if(fd == NULL) { 
                printf("errore nella creazione del file mittenti.txt"); 
                return; 
               } 
               fclose(fd);

               //creo anche il file daNotificare.txt che conterrà
               //le notifiche da inviare all'utente, tali notifiche 
               //riguardano la ricezione dei messaggi pendenti inviati dall'utente 
               //a utenti destinatari offline
               memset(dest,0, DIM_PATH + DIM_MAX + 12); 
               sprintf(dest, "%sdaNotificare.txt", path);
                fd = fopen(dest, "w"); 
               if(fd == NULL) { 
                printf("errore nella creazione del file daNotificare.txt"); 
                return; 
               } 
               fclose(fd);
  
              }
            fclose(fptr); 
        ret = send(i, (void*) risposta, RESPONSE_LEN, 0);
        if(ret < 0){
         perror("Errore in fase di comunicazione \n");
         exit(-1); 
        }
      
     }
 
}
