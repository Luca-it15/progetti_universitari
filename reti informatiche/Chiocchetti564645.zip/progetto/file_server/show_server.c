//se richiesta da un utente, la funzione show mostra i messaggi
//pendenti inviati da un determinato utente
//la funzione si preoccupa di inviare il contenuto del file 
//e dopo averlo fatto lo cancella. 
//per questo dobbiamo essere sicuri che il device riceva il messaggi. 
//dopo aver inviato i messaggi pendenti, inviamo la notifica al mittente.
//l'operazioni di cancellazione verrà fatta alla fine quando 
//tutto è andato bene

int show_server(int sd, char* userUtente, fd_set* master) {
  
 char path[DIM_PATH + DIM_MAX]; 
 char dest[DIM_PATH + DIM_MAX + 12]; 
 char riga[DIM_BLOCCO]; 
 char nomeUtente[DIM_MAX]; 
 char risposta[RESPONSE_LEN]; 
 char comando[CMD_LEN + DIM_MAX]; //conterrà _showAck + nomeUtente
 uint16_t lmsg; 
 int ret, len, sd_target;
 int creato = 1;//vale 0 se il file pendenti.txt non è ancora stato creato, 1 altrimenti  
 FILE* fd = NULL; 
 
 int presenti = 0; //vale 1 se ho messaggi pendenti per nomeUtente, 0 altrimenti
   
   //attendo che il richiedente mi invii il nome sui cui 
   //vuole fare la show
   ret = recv(sd, (void*)nomeUtente, DIM_MAX, 0); 
  if(ret == 0) {
    aggiungiUtenteDisconnesso(aggiungiLogout(nomeUtenteConnesso(sd), getTimestamp())); 
    FD_CLR(sd, master); 
   } else if(ret < 0) {
      perror("Errore nella recv\n"); 
      aggiungiUtenteDisconnesso(aggiungiLogout(nomeUtenteConnesso(sd), getTimestamp()));
      FD_CLR(sd, master);
      return 0; 
     }



  // printf("Sono dentro la show server\n");  
   sprintf(path,"utenti_server/%s_server/%sPendenti.txt", userUtente, nomeUtente); 
  // printf("voglio aprire il file: %s\n", path); 

   fd = fopen(path, "r"); 
   if(fd == NULL) { 
     creato = 0;  
   }

  //ciclo le righe e invio le righe corrispondenti
     while(creato && fgets(riga, DIM_BLOCCO, fd) != NULL) { 
     
       len = strlen(riga) + 1; 
       lmsg = htons(len); 

       ret = send(sd, (void*)&lmsg, sizeof(uint16_t), 0); 
       if(ret < 0) {
         perror("Errore nella send\n"); 
        aggiungiUtenteDisconnesso(aggiungiLogout(nomeUtenteConnesso(sd), getTimestamp())); 
         FD_CLR(sd, master);
         return 0;
       }
       ret = send(sd, (void*)riga, len, 0); 
       if(ret < 0) {
         perror("Errore nella send\n"); 
         aggiungiUtenteDisconnesso(aggiungiLogout(nomeUtenteConnesso(sd), getTimestamp())); 
         FD_CLR(sd, master);
         return 0;
       }
      // printf("ho mandato: %s\n", riga);
       memset(riga, 0, DIM_BLOCCO); 
       memset(risposta, 0, RESPONSE_LEN); 
 
       ret = recv(sd, (void*)risposta, DIM_RESPONSE, 0); 
       if(ret == 0) {
        aggiungiUtenteDisconnesso(aggiungiLogout(nomeUtenteConnesso(sd), getTimestamp())); 
         FD_CLR(sd, master); 
       } else if(ret < 0) {
         perror("Errore nella recv\n"); 
         aggiungiUtenteDisconnesso(aggiungiLogout(nomeUtenteConnesso(sd), getTimestamp())); 
         FD_CLR(sd, master);
         return 0; 
       }
        presenti = 1;
      //  printf("ho ricevuto: %s\n", risposta); 
       
     }

//ho finito di mandare il file quindi mando il comando 
     memset(risposta, 0, RESPONSE_LEN);
     strcpy(risposta, "_showfine\0"); 
      
      len = strlen(risposta) + 1; 
      lmsg = htons(len); 

     ret = send(sd, (void*)&lmsg, sizeof(uint16_t), 0); 
      if(ret < 0) {
        perror("Errore nella send\n"); 
         aggiungiUtenteDisconnesso(aggiungiLogout(nomeUtenteConnesso(sd), getTimestamp())); 
        FD_CLR(sd, master);
        return 0;
       }
     
 
     ret = send(sd, (void*)risposta, len, 0); 
     if(ret < 0) {
         perror("Errore nella send\n"); 
         aggiungiUtenteDisconnesso(aggiungiLogout(nomeUtenteConnesso(sd), getTimestamp())); 
         FD_CLR(sd, master);
         return 0;
       } 

       
     memset(risposta, 0, RESPONSE_LEN);  
     //per un ulteriore controllo, attendiamo la risposta dal richiedente
     ret = recv(sd, (void*)risposta, DIM_RESPONSE, 0); 
       if(ret == 0) {
         aggiungiUtenteDisconnesso(aggiungiLogout(nomeUtenteConnesso(sd), getTimestamp())); ; 
         FD_CLR(sd, master); 
       } else if(ret < 0) {
         perror("Errore nella recv\n"); 
         aggiungiUtenteDisconnesso(aggiungiLogout(nomeUtenteConnesso(sd), getTimestamp())); 
         FD_CLR(sd, master);
         return 0; 
       }

 if(creato)
   fclose(fd); 

//se erano presenti messaggi pendenti
if(presenti) {
 //notifichiamo all'utente mittente dei messaggi che 
  //sono arrivati a destinazione
  sd_target = socketUtenteConnesso(nomeUtente); 
  if(sd_target == -1) {
    //l'utente è offline, inserisco il suo nome nel file 
    //degli utenti da notificare
   sprintf(dest, "utenti_server/%s_server/daNotificare.txt", nomeUtente); 
   fd = fopen(dest, "a+"); 
   if(fd == NULL) {
     printf("Errore nell'apertura del file daNoticare.txt\n"); 
     return 0; 
   }

   fprintf(fd, "%s\n", userUtente); 
   fclose(fd); 

  } else {
   //l'utente è online, quindi gli mando il comando _showAck 
   //per notificare l'avvenuta ricezione dei messaggi
   sprintf(comando, "_showAck %s", userUtente); 
   
   
   ret = send(sd_target,(void*)comando, CMD_LEN + DIM_MAX, 0); 
   if(ret < 0) {
     perror("Errore nella send\n");
     return 0;
   }
 
  }
  
  //una volta ricevuta la risposta andiamo a cancellare il file,
  //ci basterà aprire il file in scrittura  
   fd = fopen(path, "w"); 
   if(fd == NULL) {
     printf("Errore nell'apertura del file\n"); 
     return 0; 
   }
     
   fclose(fd);

 }
  return 1; 
}
