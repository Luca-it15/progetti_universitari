//il file contiene la funzione che mi permette di aggiungere un
//utente alla rubrica dei contatti
int addr(int serverSocket,char* userUtente, char* username, int* status) { 

 char * cmd = "_contrU\0";
 char risp[RESPONSE_LEN]; 
 FILE* fptr; 
 int ret; 
 struct stat st = {0};
 char path[DIM_MAX + DIM_PATH]; //nome della path in cui verrà creata la directory 
 char nomeFile[2*DIM_MAX + DIM_PATH];

 //invio al server il comando per controllare l'username
 ret = send(serverSocket, (void*)cmd, CMD_LEN, 0); 
 if(ret < 0) {
     perror("Errore nella send: \n");
     exit(0); 
 }
 //invio al server l'username
 ret = send(serverSocket, (void*)username, DIM_MAX, 0); 
 if(ret < 0) {
     perror("Errore nella send: \n");
     exit(0); 
 }
 
 ret = recv(serverSocket, (void*)risp, RESPONSE_LEN, 0); 
 if( ret < 0) { 
   perror("Errore nella recv: \n"); 
   exit(0); 
 } else if(ret == 0) {
     printf("Server spento, impossibile verificare la correttezza dell'username\n"); 
     *status = 0; 
     return 0; 
 } 

 if(strcmp(risp, "_valido") != 0) {
    printf("username %s non valido \n",username); 
    return 0; 
  }
  
  sprintf(path, "utenti_device/%s_device/", userUtente);
  if(stat(path, &st) == -1){
        mkdir(path, 0750);
    }
  
  sprintf(nomeFile, "%s/rubrica.txt", path);
  //l'username è valido quindi lo aggiungo in rubrica 
  fptr = fopen(nomeFile,"a+");
  
  if(fptr == NULL) {
     printf("Impossibile aggiungere a rubrica\n"); 
     return 0;  
  }
  //aggiungo l'username in rubrica
  fprintf(fptr, "%s\n",username);

  fclose(fptr);
  return 1; 
}