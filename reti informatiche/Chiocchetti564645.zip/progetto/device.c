//Codice del device per il progetto di reti informatiche
#include"lib-1.0/utility.c"
#include"lib-1.0/controlli.c"
#include"lib-1.0/stampe.c"
#include"lib-1.0/connessione.c"
#include"lib-1.0/operazioni_file.c"
#include"file_device/in_device.c"
#include"file_device/signup_device.c"
#include"file_device/controllaNotifiche_device.c"
#include"file_device/share_device.c"
#include"file_device/show_device.c"
#include"file_device/aggiornaChat_device.c"
#include"file_device/chat_device.c"
#include"file_device/addr_device.c"
#include"file_device/listr_device.c"
#include"file_device/remover_device.c"
#include"file_device/hanging_device.c"

int main(int argc, char** argv) { 
    int porta, listener, ret, i, sd_server; 
    uint16_t lmsg;//mi serve perchè mi invieranno la dimensione del comando
    struct sockaddr_in my_addr;
    char buffer[BUF_LEN]; 
    char input[DIM_INPUT]; 
    char comando[CMD_LEN];
    char password[DIM_MAX]; 
    char username[DIM_MAX]; 
    char nomeGruppo[DIM_MAX]; //conterrà il nome del gruppo a cui veniamo aggiunti
    char risposta[CMD_LEN + DIM_MAX]; 
    char* userUtente; //conterrà l'username dell'utente attualmente loggato sul device
    char porta_cmd[DIM_PORTA]; 
    
     
    int len; //mi servirà per recuperare la lunghezza delle stringhe

    int serverStatus; //mi servirà per sapere lo status del server: 0 offline, 1 online 
    struct utenteApplicazione *ua; 
    int fdmax;

    int porta_srv; 


    FILE* fd = NULL; 
    
    uo = NULL; 
    group = NULL;  

    fd_set master;
    fd_set read_fds; 
    fd_set socketChat; 

    if(argc < 2) {
      printf("inserire il numero di porta oltre al comando\n");
      exit(-1);  
    }
    if(controllaPorta(argc, argv, 1) == -1)
      //la porta inserita è errata
        return -1;  
   
    porta = atoi(argv[1]);  


    /*rendo il device un server per permettere la comunicazione peer to peer*/
    listener = socket(AF_INET, SOCK_STREAM, 0);
    /* Creazione indirizzo di bind */
    memset(&my_addr, 0, sizeof(my_addr));
    my_addr.sin_family = AF_INET;
    my_addr.sin_port = htons(porta);
    my_addr.sin_addr.s_addr = INADDR_ANY;


    ret = bind(listener, (struct sockaddr*)&my_addr, sizeof(my_addr) );

    if( ret < 0 ){
    perror("Bind non riuscita\n");
    exit(0);
    }

    listen(listener, 30);

    stampaMenuInizialeDevice(porta); 
    while(1) {

     memset(buffer, 0, sizeof(buffer));
     read(STDIN_FILENO, buffer, DIM_MAX); 

     sscanf(buffer, "%s %s %s %s", comando,porta_cmd,username, password); 
     porta_srv = atoi(porta_cmd); 
     if(strcmp(comando, "signup") == 0) { 
      signup_device(porta_srv, comando, username, password);  
     }
     else if(strcmp(comando, "in") == 0) {
        //mi ritorna il descrittore socket con cui sono connesso al server 
        sd_server = in_device(porta_srv,porta, comando, username, password);
        if(sd_server) { 
          //mi salvo l'username dell'utente attualmente connesso sul device
          len = strlen(username); 
          userUtente = (char*)malloc(sizeof(char)*len); 
          strcpy(userUtente, username); 
          serverStatus = 1; 
        
           break; //esco dal ciclo per andare dentro all'applicazione
        }
     }
     else if(strcmp(comando, "esc") == 0) {      
      exit(0);    
     } 
     else 
      printf("Digitare un comando corretto\n"); 
      
   }
   //sono dentro all'applicazione 
   // Reset FDs
   FD_ZERO(&master);
   FD_ZERO(&read_fds);

  // Aggiungo il socket di ascolto (listener), creato dalla socket()
  // all'insieme dei descrittori da monitorare (master)
  FD_SET(sd_server, &master);
  FD_SET(listener, &master);
  FD_SET(STDIN_FILENO, &master); 
  // Aggiorno il massimo
  fdmax = (sd_server > listener) ? sd_server : listener;
  stampaMenuDevice(userUtente);
  //una volta che il login è andato a buon fine, chiedo al 
  //server se ci sono notifiche per me

  controllaNotifiche(sd_server, userUtente); 

     while(1){ 
        read_fds = master;

        select(fdmax+1, &read_fds, NULL, NULL, NULL);

        // scorro  i descrittori
        for(i=0; i<=fdmax; i++){
            if(FD_ISSET(i, &read_fds)){ 
                if(i==sd_server){ 
                 memset(risposta, 0, CMD_LEN + DIM_MAX); 
                  ret = recv(i, (void*)risposta, CMD_LEN + DIM_MAX, 0); 
                  if(ret < 0) {
                     perror("Errore in fase di ricezione del messaggio: \n");
                     exit(-1);
                  } else if(ret == 0) {
                      serverStatus = 0;
                      FD_CLR(sd_server, &master);
                      close(sd_server);
                      continue;
                  }
                  memset(comando, 0, CMD_LEN); 
                  memset(username, 0, DIM_MAX); 
                  sscanf(risposta, "%s %s", comando, username); 
                  if(strcmp(comando, "chat") == 0) { 
                    //mando il presence ack, in modo da poter segnare al server
                    //che sono online
                    memset(risposta, 0, CMD_LEN + DIM_MAX);
                    strcpy(risposta, "presence ack\0"); 
                    ret = send(i, (void*) risposta, strlen(risposta), 0); 
                    if(ret < 0) { 
                      perror("errore in fase di invio della risposta: \n"); 
                    }
                  }
                   else if(strcmp(comando, "_showAck") == 0) {
                     notifica(5, username);
                     if(!aggiornaChat(userUtente, username))
                      printf("Errore nell'aggiornamento della chat\n");      
                  }

           
          } 
          else if(i == listener) { 
            accettaConnessione(listener, &fdmax, &master); 
          } 
          else if(i==0 ){
                    // input da tastiera dell'utente
                    //qua scrivo comandi, non messaggi
                    read(STDIN_FILENO, input, DIM_INPUT);
                    memset(&username, 0, sizeof(username));
                    sscanf(input, "%s %s\n", comando, username);
                    // controllo quale comando è stato digitato
                    if(strcmp(comando, "chat")==0){
                        if(strcmp(username,userUtente)==0){
                            printf("Non puoi chattare con te stessso\n");
                            continue;
                        }else if(strlen(username) == 0){
                            printf("Specifica uno username\n");
                            break;
                        }
                       
                        chat_device(sd_server,listener,&fdmax,&master,username, 
                                   &socketChat,userUtente, &serverStatus); 
                         
                     } else if(strcmp(comando, "hanging")==0){
                       hanging(sd_server, &serverStatus, &master);
                     } else if(strcmp(comando,"show")==0){
                        if(strlen(username) == 0){
                            printf("Specifica uno username\n");
                           continue;
                        } else if(strcmp(username, userUtente) == 0){
                            printf("Non puoi fare show con te stesso\n");
                           continue;
                        }
                        printf("comando show\n");
                        if(show_device(sd_server, username, userUtente, &master, &serverStatus) == 0)
                          printf("Errore nella show\n");  
                        continue; 
                     }  else if(strcmp(comando, "out")==0){
                        //chiudo tutti i socket ed esco
                        close(listener); 
                        ua = uo; 
                        while(ua != NULL) {
                         close(ua->sd); 
                         ua = ua->next; 
                        }
                        exit(0); 
                     } else if(strcmp(comando, "share") == 0){
                        printf("Devi essere dentro una chat per condividere un file.\n");
                        break;
                    } else if(strcmp(comando, "addr")== 0 && serverStatus) {
                       if(addr(sd_server,userUtente, username, &serverStatus))
                        printf("aggiunto %s in rubrica\n", username); 
                       else 
                        printf("impossibile aggiungere %s in rubrica\n",username);  

                    } else if(strcmp(comando,"remover") == 0) {
                      if(remover(userUtente, username))
                       printf("%s è stato rimosso dalla rubrica\n", username); 
                      else 
                       printf("impossibile rimuovere %s dalla rubrica\n", username); 
                    }else if(strcmp(comando, "listr") == 0) {
                       listr(userUtente); 
                    }
                    else
                        printf("Comando errato\n");
               } else {
                  //qualcuno mi ha inviato un messaggio
                  memset(buffer, 0, sizeof(buffer)); 
                   ret = recv(i, (void*)&lmsg, sizeof(uint16_t), 0);
                 if(ret < 0) { 
                  perror("Errore nella receive\n");   
                  // si è verificato un errore
                  close(i);
                  // rimuovo il descrittore newfd da quelli da monitorare
                  FD_CLR(i, &master); 
                 }
                 else if(ret == 0) {    
                  close(i);
                  FD_CLR(i, &master); 
                  continue;      
                 }
                 // Rinconverto la dimensione in formato host     
                 len = ntohs(lmsg); 
                 // Ricevo i dati
                 ret = recv(i,(void*)buffer,len,0); 
                 if(ret < 0) { 
                 perror("Errore nella receive\n");   
                 // si è verificato un errore
                 close(i);
                 // rimuovo il descrittore newfd da quelli da monitorare
                 FD_CLR(i, &master);  
                 } 
                  memset(comando, 0, sizeof(comando)); 
                  memset(username, 0, sizeof(username)); 
                  sscanf(buffer, "%s %s %s", comando, username, nomeGruppo);
                  if(nomeUtenteConnesso(i) != NULL) {  
                    //in questa parte ricevo i messaggi da chi si è 
                    //gia connesso con me, ovvero chi mi ha gia fatto chat
                    if(strcmp(comando,"_share") == 0) {
                       notifica(4, nomeUtenteConnesso(i));
                       printf("//--- HAI RICEVUTO IL FILE %s DA %s ---//\n", username, nomeUtenteConnesso(i));  
                       recv_file(i, username, userUtente, &master,&socketChat); 
                      continue; 
                    }
                    if(strncmp(buffer, "\\q", 2) != 0) {
                      if(membroDelGruppo(i) == 1) {
                        //notifico il messsaggio da parte del gruppo solo se diverso dal comando _group
                        if(strncmp(buffer,"_group",6 ) != 0 &&
                         strncmp(buffer,"_inGroup",8 ) != 0) {
                         notifica(3, idGruppo(i)); 
                           salvaMessaggioSuFile(fd, userUtente,nomeUtenteConnesso(i), idGruppo(i),
                                                 getTimestamp(), buffer, 0);
                        }
                       } else 
                        notifica(1,nomeUtenteConnesso(i)); 
                        salvaMessaggioSuFile(fd, userUtente,nomeUtenteConnesso(i), nomeUtenteConnesso(i),
                                             getTimestamp(), buffer, 0);
                   } else {
                     printf("l'utente %s e' uscito\n", nomeUtenteConnesso(i)); 
                   }
                  }
                  else {  
                     //in questa parte ricevo i messaggi da chi non è ancora 
                     //connesso con me, i messaggi saranno gli eventuali comandi
                     //per iniziare una chat o un creare un gruppo 
                   if(strcmp(comando,"_chat") == 0) {  
                    aggiungiUtenteOnline(i, username, " ", " ");  
                    notifica(0,username); 
                    continue; 
                   }
                   else if(strcmp(comando,"_group") == 0 ||
                     strcmp(comando,"_inGroup") == 0) {  
                    aggiungiUtenteOnline(i, username, " ", " ");
                    if(membroDelGruppo(i) == 0)
                    aggiungiAGruppo(i,nomeGruppo); 
                   FD_SET(i, &socketChat); 
                   if(strcmp(comando,"_inGroup") == 0)
                    notifica(2, nomeGruppo); 
                      continue;    
                   } 
                   else if(strcmp(comando, "_share") == 0) {
                    notifica(4, nomeGruppo); 
                    printf("//--- HAI RICEVUTO IL FILE %s DA %s ---//\n", username, nomeGruppo);
                    recv_file(i, username, userUtente, &master,&socketChat); 
                    continue; 
                   } 
                }
             
            } 
        }
    }
   }
  return 0; 
}


