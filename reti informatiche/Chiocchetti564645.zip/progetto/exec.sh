# 1. COMPILAZIONE
# Il comando 'make' necessita del makefile, che deve essere
# creato come descritto nella guida sulla pagina Elearn

  make

  read -p "Compilazione eseguita. Premi invio per eseguire..."

# 2. ESECUZIONE
# 2.1 esecuzioe del server sulla porta 4243
  gnome-terminal -x sh -c "./serv 4243; exec bash"

# 2.2 esecuzione di 3 device sulle porte {5001,...,5003}
  for port in {5001..5003}
  do
     gnome-terminal -x sh -c "./dev $port; exec bash"
  done
