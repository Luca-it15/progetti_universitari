//Codice del server per il progetto di reti informatiche
#include"lib-1.0/utility.c"
#include"lib-1.0/controlli.c"
#include"lib-1.0/stampe.c"
#include"lib-1.0/connessione.c"
#include"lib-1.0/operazioni_file.c"
#include"file_server/in_server.c"
#include"file_server/chat_server.c"
#include"file_server/signup_server.c"
#include"file_server/bufferizza_Messaggio.c"
#include"file_server/addr_server.c"
#include"file_server/listaUtenti_server.c"
#include"file_server/hanging_server.c"
#include"file_server/show_server.c"
#include"file_server/controllaNotifiche_server.c"



int main(int argc, char* argv[]) {
  

int ret, newfd, listener, i, porta, ris;
socklen_t addrlen;  

fd_set master;
fd_set read_fds;
fd_set fdChat; 
int fdmax;   
struct sockaddr_in my_addr, cl_addr;
char buffer[CMD_LEN];  
struct timeval timeout = {0, 0}; 
char* nome; 

//variabile della struttura utentiOnline, mi servirà per tenere 
//una lista degli utenti online e offline
uo = NULL; 
uno = NULL;
struct utenteApplicazione* utente = NULL; 

if(argc < 2) {
   porta = 4242; 
} else  {
  if(controllaPorta(argc, argv, 0) == -1) 
  //il numero di porta inserito è errato
    return -1; 
  porta = atoi(argv[1]);
}
   
/* Creazione socket di ascolto*/
listener = socket(AF_INET, SOCK_STREAM, 0);

/* Creazione indirizzo di bind */
memset(&my_addr, 0, sizeof(my_addr));
my_addr.sin_family = AF_INET;
my_addr.sin_port = htons(porta);
my_addr.sin_addr.s_addr = INADDR_ANY;


ret = bind(listener, (struct sockaddr*)&my_addr, sizeof(my_addr) );

if( ret < 0 ){
perror("Bind non riuscita\n");
exit(1);
}

listen(listener, 50);

// Reset FDs
FD_ZERO(&master);
FD_ZERO(&read_fds);

// Aggiungo il socket di ascolto (listener), creato dalla socket()
// all'insieme dei descrittori da monitorare (&master)
FD_SET(listener, &master);
FD_SET(STDIN_FILENO, &master); 
// Aggiorno il massimo
fdmax = listener;
stampaMenuServer();

while(1){ 
 // Inizializzo il set read_fds, manipolato dalla select()
 read_fds = master; 
 ret = select(fdmax+1, &read_fds, NULL, NULL, &timeout);
 if(ret<0){
 perror("ERRORE SELECT:");
 exit(1);
}
for(i = 0; i <= fdmax; i++) {
fflush(stdout); 
memset(buffer, 0, sizeof(buffer));
    
// controllo se i è pronto
 if(FD_ISSET(i, &read_fds)) {
//se il descrittore del file di stdin è pronto eseguo i comandi dell'utente    
 if(i == 0){
   scanf("%s",buffer);       
  if(strncmp(buffer, "help",4) == 0) {
      printf("help\n"); 
      help(); 
    }
    else if(strncmp(buffer,"list",4) == 0) {
        printf("sono in list\n");
        printf("\n\n"); 
        printf("Mostro la lista degli utenti online:\n\n");  
        stampaUtenti(uo); 
    }
    else if(strncmp(buffer, "esc",3) == 0) {  
       printf("CHIUDO IL LISTENER!\n");
       fflush(stdout);
       close(listener);     
       //chiudiamo tutti i socket di comunicazione creati
       utente = uo; 
       while(utente != NULL) {
         close(utente->sd); 
         utente = utente->next; 
       } 
      exit(0);    
   }  
   continue; 
 }  
// se i è il listener, ho ricevuto una richiesta di connessione
// (un client ha invocato connect())
else if(i == listener) {
fflush(stdout);
addrlen = sizeof(cl_addr);
// faccio accept() e creo il socket connesso 'newfd'
newfd = accept(listener,
         (struct sockaddr *)&cl_addr, &addrlen);
FD_SET(newfd, &master);

// Aggiorno l'ID del massimo descrittore
if(newfd > fdmax){ fdmax = newfd; }
} 
else { 
    //inizia il dialogo tra server e device
    //controllo se il messaggio è destinato a un utente
     if(FD_ISSET(i, &fdChat)) { 
          //archivio il messaggio su file, nel formato
          //nome utente
          //messaggio
          //timestamp
      ris = bufferizzaMessaggio(i, &master, nomeUtenteConnesso(i)); 

      if(ris == 0)
         printf("errore nella bufferizzazione del messaggio\n"); 
      else if(ris == 2) {
        printf("l'utente esce dalla chat con me\n"); 
        FD_CLR(i, &fdChat); 
      }   

    }
    //ricevo il comando dal device che vuole eseguire 
    else { 
     memset(buffer, 0, CMD_LEN); 
     ret = recv(i, (void*)buffer,CMD_LEN, 0);
     if(ret == 0){
      nome = nomeUtenteConnesso(i); 
      utente = aggiungiLogout(nome,getTimestamp()); 
        if(utente != NULL) {  
        aggiungiUtenteDisconnesso(utente);  
        }  
      fflush(stdout);
      // il client ha chiuso il socket, quindi
      // chiudo il socket connesso sul server
      close(i);
      // rimuovo il descrittore newfd da quelli da monitorare
       FD_CLR(i, &master);
       continue; 
       }
     else if(ret < 0){
      perror("ERRORE! \n");
      // si è verificato un errore
      close(i);
      // rimuovo il descrittore newfd da quelli da monitorare
      FD_CLR(i, &master);
      }
     else{
       //il comando inviato è significativo, eseguo il comando specificato
        fflush(stdout);
        if(strcmp(buffer, "signup") == 0) {
            //eseguo la risposta alla signup passandoli il socket di comunicazione
          signup_server(i, &master); 
          fflush(stdout); 
        }
        else if(strcmp(buffer,"in") == 0){
          //eseguo la risposta alla in 
          in_server(i, &master, uo); 
        } 
        else if(strcmp(buffer,"chat") == 0) { 
          nome = nomeUtenteConnesso(i); 
          //vado a gestire la chat
          chat_server(i, nome, &fdChat, &master, uo, uno); 
        } //if
        else if(strncmp(buffer, "\\u",2) == 0) { 
           if(!listaUtenti_server(i, uo, &master))
            printf("Errore nel mandare la lista degli utenti online\n"); 
       } 
         else if(strcmp(buffer,"_contrU") == 0) { 
           addr_server(i); 
        } else if(strcmp(buffer,"_hanging") == 0) { 
          if(!hanging_server(i, &master, nomeUtenteConnesso(i), &fdChat)) {
            printf("Errore nell'esecuzione della hanging\n"); 
          }  
         } 
         else if(strcmp(buffer,"_show") == 0) {
          if(!show_server(i, nomeUtenteConnesso(i),&master)) {
            printf("Errore nell'esecuzione della show\n");   
          }
        }
        else if(strcmp(buffer, "_notifiche\0") == 0) {
          controllaNotificheServer(i, &master); 
        }
       } //else
      } //else
     } //else
    } //if
   } //for
 } //while
}
